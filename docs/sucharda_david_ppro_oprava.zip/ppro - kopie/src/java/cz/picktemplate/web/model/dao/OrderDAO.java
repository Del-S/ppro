package cz.picktemplate.web.model.dao;

public interface OrderDAO {
/* get adress, set adress etc */
}
